                                                                                                                                                               
procedure main (void)
{
  int counter; 
 
                    
 

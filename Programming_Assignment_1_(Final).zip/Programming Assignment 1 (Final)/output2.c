                                                     
                                                     
                                                     
procedure main (void)
{
  int                   counter; 

  counter =       100;
                     
  printf ("counter = %d\n", counter);
}

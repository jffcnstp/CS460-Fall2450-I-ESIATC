/*
 * CS460
 * Programming Assignment 1: Ignore Comments
 * Date: September 11, 2024
 * Team: Fifty If-Else Statements in a Trench Coat (FIESTC)
 * Members: Ryan Nguyen
 *          Anthony Tara
 *          Jericho Cariaga
 *          Jeff Huang
 *          Adam Erskine
 *
 * This program is meant to take a C style program file and replace all comments with whitespace
 */

#include <iostream>
#include <fstream>

void ignoreComments(const std::string& fileName, const std::string& outputName) {
    std::ifstream inputFile(fileName);
    std::ofstream outputFile(outputName);

    if (!inputFile) {
        std::cerr << "Error opening input file: " << fileName << std::endl;
        exit(1);
    }

    if (!outputFile) {
        std::cerr << "Error opening output file: " << outputName << std::endl;
        exit(1);
    }

    char currentChar;
    int lineNum=1;
    int commentErrorLine;
    enum DFAState { Normal, Slash, SingleLine, MultiLine, MultiLineEnd, DoubleQuote,IllegalChar };
    DFAState state = Normal;


    while (inputFile.get(currentChar)) {
        if(currentChar == '\n')
            {
                lineNum+=1;
            }
        switch (state) {
            case Normal:
                if (currentChar == '/') {
                    state = Slash;
                }
                else if (currentChar == '\"') {
                    outputFile.put(currentChar);
                    state = DoubleQuote;
                }
                else if ( currentChar == '*')
                    state = IllegalChar;
                else {
                    outputFile.put(currentChar);
                }
                break;
            case Slash:
                if (currentChar == '/') {
                    outputFile.put(' ');
                    state = SingleLine;
                }
                else if (currentChar == '*') {
                    outputFile.put(' ');
                    state = MultiLine;
                    commentErrorLine=lineNum;
                }
                else {
                    state = Normal;
                    outputFile.put('/');
                    outputFile.put(currentChar);
                }
                break;
            case SingleLine:
                if (currentChar != '\n') {
                    outputFile.put(' ');
                }
                else {
                    outputFile.put('\n');
                    state = Normal;
                }
                break;
            case MultiLine:
                if (currentChar == '*') {
                    outputFile.put(' ');
                    state = MultiLineEnd;
                }
                else if (currentChar == '\n') {
                    outputFile.put('\n');
                }
                else {
                    outputFile.put(' ');
                }
                break;
            case MultiLineEnd:
                if (currentChar == '/') {
                    outputFile.put(' ');
                    outputFile.put(' ');
                    state = Normal;
                }
                else if(currentChar == '*')
                {
                    outputFile.put(' ');
                }
                else {
                    state = MultiLine;
                }
                break;
            case DoubleQuote:
                if (currentChar != '\"') {
                    outputFile.put(currentChar);
                }
                else if (currentChar == '\n') {
                    outputFile.put('\n');
                }
                else {
                    outputFile.put(currentChar);
                    state = Normal;
                }
                break;
            case IllegalChar:
                if(currentChar =='/')
                    {
                        inputFile.close();
                        outputFile.close();
                        std::cout << "ERROR: Program file " << fileName << " contains C-style, unterminated comment on line " << lineNum << std::endl;
                        exit(3);
                    }
        }
    }

    inputFile.close();
    outputFile.close();
    if(state==MultiLine)
        std::cout << "ERROR: Program file " << fileName << " contains C-style, unterminated comment on line " << commentErrorLine << std::endl;
    else
        std::cout << "Comments in file: " << fileName << " successfully ignored.\n";
}

int main() {
    ignoreComments("../programming_assignment_1-test_file_1.c", "../output1.c");
    ignoreComments("../programming_assignment_1-test_file_2.c", "../output2.c");
    ignoreComments("../programming_assignment_1-test_file_3.c", "../output3.c");
    ignoreComments("../programming_assignment_1-test_file_4.c", "../output4.c");

    ignoreComments("../programming_assignment_1-test_file_5.c", "../output5.c");
    ignoreComments("../programming_assignment_1-test_file_6.c", "../output6.c");

    return 0;
}
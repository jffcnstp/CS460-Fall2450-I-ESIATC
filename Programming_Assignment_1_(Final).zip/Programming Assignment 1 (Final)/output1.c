                                                     
                                                     
                                                     
procedure main (void)
{
  int counter;

  counter = 2;
  
                
   
  printf ("counter = %d\n", counter);
}

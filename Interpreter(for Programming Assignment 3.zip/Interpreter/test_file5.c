                                                     
                                                     
                                                     
procedure main (void)
{
  char buffer[+10];

  buffer[0] = "_\";                                          
}

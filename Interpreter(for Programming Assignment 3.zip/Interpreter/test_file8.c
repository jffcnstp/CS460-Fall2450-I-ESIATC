                                                     
                                                     
                                                     
procedure main (void)
{
  char void;                                                                          
}

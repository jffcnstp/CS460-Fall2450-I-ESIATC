                                                     
                                                     
                                                     
procedure main (void)
{
  char char;                                                                          
}

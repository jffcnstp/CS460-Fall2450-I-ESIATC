                                                     
                                                     
                                                     
procedure main (void)
{
  char buffer[-5];                                                                  
}

/***************************************************
 * CS460: Programming Assignment 4: Test Program 6 *
 ***************************************************/

char announcement[2048];


procedure main (void)
{
  char name[100];
}


function bool my_function (char byte)
{
  int i, j;
  bool found_something;
  int found_something;

  return found_something;
}


procedure do_nothing (int i, int j, int k)
{
}


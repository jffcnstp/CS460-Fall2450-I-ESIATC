// ***************************************************
// * CS460: Programming Assignment 3: Test Program 8 *
// ***************************************************
procedure main (void)
{
  char void; // syntax error: reserved word "void" cannot be for the name of a variable
}
